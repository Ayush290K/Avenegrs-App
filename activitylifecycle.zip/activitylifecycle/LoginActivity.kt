package com.internshala.activitylifecycle

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
// onclicklistner is an interface inside the view class and we are importing it here.
    // whenever we use interface we also use all the member functions of it using override keyword.
    var etMobileNumber: EditText? = null
    var etPassword: EditText? = null
    lateinit var btnLogin: Button
    lateinit var txtForgotPassword: TextView
    lateinit var txtRegister: TextView

    val validmobilenumber= "9031943454"
    val validPassword = arrayOf("tony","steve","bruce","thanos")

    lateinit var sharedpreferences: SharedPreferences



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        sharedpreferences = getSharedPreferences(getString(R.string.preferences_file_name), Context.MODE_PRIVATE)
        val isLoggedIn = sharedpreferences.getBoolean("isLoggedIn", false)
        if(isLoggedIn){
            val intent = Intent(this@LoginActivity, AvengersActivity::class.java)
            startActivity(intent)
        } else{
            setContentView(R.layout.activity_login)
        }

        title = "Login"

        val mobilenumber = etMobileNumber?.text.toString()

        val password = etPassword?.text.toString()

        // we will use the findviewbyid() function to find the view related with each variable.
        etMobileNumber = findViewById(R.id.etMobileNumber)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtRegister = findViewById(R.id.txtRegister)
        btnLogin.setOnClickListener {
            val mobilenumber = etMobileNumber?.text.toString()

            val password = etPassword?.text.toString()

            var nameofavengers = "Avengers"
            val intent = Intent(this@LoginActivity, AvengersActivity::class.java)

            if((mobilenumber == validmobilenumber)){
                if(password == validPassword[0]){

                    nameofavengers = "Iron Man"
                    savepreferences(nameofavengers)
                    startActivity(intent)
                } else if(password == validPassword[1]){

                    nameofavengers = "Steve"
                    savepreferences(nameofavengers)

                    startActivity(intent)
                } else if(password==validPassword[2]){

                    nameofavengers = "Bruce"
                    savepreferences(nameofavengers)

                    startActivity(intent)
                } else if(password == validPassword[3]){

                    nameofavengers == "Avengers"
                    savepreferences(nameofavengers)

                    startActivity(intent)
                }
            }else{
                Toast.makeText(this@LoginActivity, "Invalid Credentials!", Toast.LENGTH_LONG).show()
            }
        }



    }
    override fun onPause() {
        super.onPause()
        finish()
    }

    fun savepreferences(title:String){
        sharedpreferences.edit().putBoolean("isLoggedIn", true).apply()
        sharedpreferences.edit().putString("title", title).apply()
    }


}