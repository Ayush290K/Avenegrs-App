package com.internshala.activitylifecycle

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
// AppCompatActivity is a class which is defined under a library and it is being inherited.
class AvengersActivity : AppCompatActivity() {
    // savedInstanceState it is basically a parameter which is basically used to get seemless
    // experience while using the app. for example when we do full screen on youtube the activity
    // changes but it does not stops the video.
    // Bundle is a data type it has and it is basically used to transfer the stored data on
    // current activity to another activity. It can have any data type like string,int,character etc.
    var titlename: String? = "Avengers"
    lateinit var sharedpreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedpreferences = getSharedPreferences(getString(R.string.preferences_file_name), Context.MODE_PRIVATE)

        setContentView(R.layout.scrollview)

        titlename = sharedpreferences.getString("Title","The Avengers")
        title = titlename

    }


}